#include <string>
#include <string.h>
#include <fstream>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <iostream>
#include<sstream>
#include<dirent.h>
#include "VMT.h"

using namespace std;

//This global variables used by all cpp files
vector<string> memo_segm_ops;
vector<string> arthim_logic_ops;
vector<string> function_ops;
vector<string> brancing_ops;
vector<string> components;
ifstream inputfile;
ofstream outputfile;
string lastfn;
string vmfilename;
char infile[200];
char outfile[200];
int operorder;
int nextaddress;

// main function
int main(int argc, char* argv[])
{

VM_Translator vmtranslator(argv[1]);

return 0;
}
